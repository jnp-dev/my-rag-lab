"""RAG 단계별 모니터링 실습 — 기본 코드 (오케스트레이터).

단일 app.py 를 8개 stage 모듈(stages/)로 나누고, 여기서 사이드바와 탭으로 연결한다.
각 단계의 '중간 데이터'는 st.session_state.kb 에 모여 각 탭에서 표시된다.

가상·공개 문서만 사용. 무료 LLM API는 입력이 학습에 쓰일 수 있음.
"""
# --- macOS OpenMP 충돌 방지: torch/faiss/sklearn 가 각자 libomp.dylib 를 싣어 ---
# --- 한 프로세스에 OpenMP 런타임이 중복 로드되면서 segfault 가 난다.        ---
# --- 반드시 네이티브 라이브러리(torch/faiss) import 전에 설정해야 효과가 있다. ---
import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("OMP_NUM_THREADS", "1")
# HuggingFace tokenizers 의 fork 병렬화가 종료 시 세마포어 누수/세그폴트를 유발 → 비활성화
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import streamlit as st


# --- Windows 프리플라이트: VC++ 재배포 누락 시 torch(c10.dll) 로드 실패를 친절히 안내 ---
def _preflight_torch():
    """깨끗한 Windows PC 에서 torch import 가 VC++ 재배포 패키지 누락으로 실패하면
    (DLL load failed / WinError 126) 트레이스백 대신 설치 안내를 띄우고 멈춘다.
    macOS/Linux 에서는 아무 일도 하지 않는다."""
    import sys
    if sys.platform != "win32":
        return
    try:
        import torch  # noqa: F401  (c10.dll → MSVC 런타임 DLL 의존 로드)
    except Exception as e:  # noqa: BLE001
        winerr = getattr(e, "winerror", None)
        low = str(e).lower()
        if winerr == 126 or "126" in low or "dll load failed" in low or "c10" in low:
            st.error(
                "**PyTorch 로드 실패 — Microsoft Visual C++ 재배포 패키지가 필요합니다.**\n\n"
                "torch 의 `c10.dll` 이 MSVC 런타임 DLL 에 의존하는데 이 PC 에 설치돼 있지 "
                "않습니다. (torch 설치 문제가 아니라 Windows 런타임 누락입니다.)\n\n"
                "**해결:** 아래를 설치 → 터미널을 새로 열고 → 앱을 다시 실행하세요.\n\n"
                "📥 https://aka.ms/vs/17/release/vc_redist.x64.exe"
            )
            st.caption(f"원본 오류: {e}")
            st.stop()
        raise  # VC++ 와 무관한 오류는 그대로 표면화


_preflight_torch()

from stages.stage1_load import load_documents
from stages.stage2_chunk import make_chunks
from stages.stage3_embed import get_model, embed
from stages.stage4_store import build_index
from stages.pipeline import run_pipeline
from stages.stage6_generate import active_provider
from stages import (stage1_load, stage2_chunk, stage3_embed, stage4_store,
                    stage5_search, stage6_generate, stage7_chat, stage8_eval)

MODELS = {
    "영어 위주 · all-MiniLM-L6-v2": "all-MiniLM-L6-v2",
    "다국어/한국어 · paraphrase-multilingual-MiniLM-L12-v2":
        "paraphrase-multilingual-MiniLM-L12-v2",
}

st.set_page_config(page_title="RAG 단계별 실습", page_icon="🔎", layout="wide")
st.title("🔎 RAG 파이프라인 단계별 실습")
st.caption("가상·공개 문서만 사용 (작전·개인정보·기밀 금지)")

with st.sidebar:
    st.header("입력 & 설정")
    files = st.file_uploader("PDF / TXT / MD", type=["pdf", "txt", "md"],
                             accept_multiple_files=True)
    include_folder = st.checkbox("docs/ 폴더 포함", value=True)
    model_name = MODELS[st.selectbox("임베딩 모델", list(MODELS.keys()))]
    c1, c2 = st.columns(2)
    size = c1.slider("청크 크기", 200, 1000, 500, 50)
    overlap = c2.slider("오버랩", 0, 200, 80, 10)
    overlap = min(overlap, size - 50)   # 오버랩이 청크 크기 이상이면 청크 폭발 → 방어
    k = st.slider("top-k", 1, 8, 4)

    if st.button("▶ 파이프라인 실행", width='stretch'):
        kb = run_pipeline(files, include_folder, model_name, size, overlap,
                          load_documents, make_chunks, get_model, embed, build_index)
        if kb is None:
            st.warning("문서가 없거나 텍스트 추출 실패(스캔본 PDF일 수 있음).")
        else:
            st.session_state.kb = kb
            st.session_state.msgs = []
            st.success(f"완료 · 문서 {len(kb['docs'])} · 청크 {len(kb['records'])}")

    _PROVIDER_NOTE = {
        "claude": "생성기: Claude (CLAUDE_API_KEY 감지)",
        "gemini": "생성기: Gemini (GEMINI_API_KEY 감지)",
        "ollama": "LLM 키 미설정 — 로컬 Ollama 로 생성(가능 시). "
                  "CLAUDE_API_KEY 또는 GEMINI_API_KEY 를 설정하면 클라우드 모델을 씁니다.",
    }
    st.info(_PROVIDER_NOTE[active_provider()])

tabs = st.tabs(["1.적재/파싱", "2.청킹", "3.임베딩", "4.저장",
                "5.검색", "6.생성", "7.챗봇", "8.평가/검수"])
kb = st.session_state.get("kb")

with tabs[0]: stage1_load.render(kb)
with tabs[1]: stage2_chunk.render(kb)
with tabs[2]: stage3_embed.render(kb)
with tabs[3]: stage4_store.render(kb)
with tabs[4]: stage5_search.render(kb, k)
with tabs[5]: stage6_generate.render(kb, k)
with tabs[6]: stage7_chat.render(kb, k)
with tabs[7]: stage8_eval.render(kb, k)
