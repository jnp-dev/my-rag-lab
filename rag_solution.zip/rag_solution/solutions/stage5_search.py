"""Stage 5 모범답안 — 검색 확장 과제:
  1) 유사도 임계값 미만 → '모름' 경고
  2) 출처별 필터(특정 문서 안에서만 검색)
  3) MMR 다양성(중복·유사 청크 줄여 다양한 근거 확보)
"""
import pandas as pd
import streamlit as st

from stages.stage3_embed import get_model
from stages.stage5_search import retrieve  # noqa: F401


def mmr(query_vec, cand_vecs, k, lam=0.7):
    """Maximal Marginal Relevance: 관련성(λ)과 다양성(1-λ)을 균형 있게 선택."""
    sim_q = cand_vecs @ query_vec
    selected, candidates = [], list(range(len(cand_vecs)))
    while candidates and len(selected) < k:
        if not selected:
            i = max(candidates, key=lambda c: sim_q[c])
        else:
            def score(c):
                div = max(float(cand_vecs[c] @ cand_vecs[s]) for s in selected)
                return lam * sim_q[c] - (1 - lam) * div
            i = max(candidates, key=score)
        selected.append(i)
        candidates.remove(i)
    return selected


def render(kb, k):
    st.subheader("Stage 5 · 검색  ✅모범답안(임계값·출처필터·MMR)")
    if not kb:
        return
    sources = ["(전체)"] + sorted({r["source"] for r in kb["records"]})
    c1, c2, c3 = st.columns(3)
    src = c1.selectbox("출처 필터", sources, key="sol_src")
    thr = c2.slider("유사도 임계값", 0.0, 1.0, 0.30, 0.05, key="sol_thr")
    use_mmr = c3.checkbox("MMR 다양성", value=False, key="sol_mmr")
    sq = st.text_input("검색어", key="sol_search_q")
    if not sq:
        return
    hits = retrieve(sq, max(k * 3, k))                # 후보 넉넉히 뽑고
    if src != "(전체)":                                # 2) 출처 필터
        hits = [h for h in hits if h["source"] == src]
    if use_mmr and hits:                              # 3) MMR 재정렬
        model = get_model(kb["model_name"])
        qv = model.encode([sq], normalize_embeddings=True).astype("float32")[0]
        cv = model.encode([h["text"] for h in hits], normalize_embeddings=True).astype("float32")
        hits = [hits[i] for i in mmr(qv, cv, k)]
    else:
        hits = hits[:k]
    if not any(h["score"] >= thr for h in hits):      # 1) 임계값
        st.warning(f"임계값 {thr:.2f} 이상 청크 없음 → '모른다'가 안전")
    st.dataframe(pd.DataFrame([
        {"순위": i + 1, "source": h["source"], "chunk_id": h["chunk_id"],
         "유사도": round(h["score"], 3), "통과": h["score"] >= thr, "미리보기": h["text"][:80]}
        for i, h in enumerate(hits)]), width='stretch')
