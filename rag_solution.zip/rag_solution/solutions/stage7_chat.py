"""Stage 7 모범답안 — 챗봇 확장 과제:
  1) 대화 초기화
  2) 답변 평가(👍/👎)
  3) 이전 대화 맥락을 반영한 후속 질문 재검색
  4) 대화 내보내기(다운로드)
  5) Gemini/Ollama 제공자 토글 (Stage 6 과 동일한 llm_controls 공용)
"""
import streamlit as st

from stages.stage5_search import retrieve
from solutions.stage6_generate import build_prompt, generate, llm_controls


def render(kb, k):
    st.subheader("Stage 7 · 챗봇  ✅모범답안(맥락검색·초기화·평가·내보내기·Gemini/Ollama)")
    if not kb:
        st.info("← 먼저 파이프라인을 실행하세요.")
        return

    provider, model_name, temp = llm_controls("chat_")     # 5) 제공자 토글
    st.session_state.setdefault("sol_msgs", [])
    c1, c2 = st.columns(2)
    if c1.button("🗑 대화 초기화"):                          # 1) 초기화
        st.session_state.sol_msgs = []
    if st.session_state.sol_msgs:                           # 4) 내보내기
        dump = "\n".join(f'{m["role"]}: {m["content"]}' for m in st.session_state.sol_msgs)
        c2.download_button("⬇ 대화 내보내기", dump.encode("utf-8"), "chat.txt")

    for m in st.session_state.sol_msgs:
        st.chat_message(m["role"]).write(m["content"])

    if q := st.chat_input("질문하세요", key="sol_chat"):
        st.chat_message("user").write(q)
        # 3) 직전 사용자 질문을 합쳐 후속 질문(대명사 등) 검색 보강
        prev = [m["content"] for m in st.session_state.sol_msgs if m["role"] == "user"]
        search_q = (prev[-1] + " " + q) if prev else q
        hits = retrieve(search_q, k)
        prompt, ctx = build_prompt(q, hits)
        with st.spinner(f"{provider} 생성 중..."):
            ans = generate(prompt, ctx, provider, model_name, temp)
        ans += "\n\n**출처:** " + ", ".join(sorted({h["source"] for h in hits}))
        st.chat_message("assistant").write(ans)
        st.session_state.sol_msgs += [{"role": "user", "content": q},
                                      {"role": "assistant", "content": ans}]

    if st.session_state.sol_msgs:                           # 2) 평가
        e1, e2 = st.columns(2)
        e1.button("👍 도움됨", key="sol_up")
        e2.button("👎 아쉬움", key="sol_down")
