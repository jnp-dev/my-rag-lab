"""Stage 4 모범답안 — 저장 확장 과제:
  1) FAISS 인덱스 디스크 저장/로드(persist)
  2) 청크 메타데이터(JSON) 함께 저장·복원 → 재시작해도 그대로 검색
"""
import json
import os

import faiss
import numpy as np
import pandas as pd
import streamlit as st

from stages.stage4_store import build_index  # noqa: F401 (app_solution이 사용)

INDEX_PATH, META_PATH = "index.faiss", "index_meta.json"


def _show_saved():
    """디스크에 저장된 인덱스/메타 파일의 내용을 화면에 표시한다(불러오지 않고 조회만)."""
    if not (os.path.exists(INDEX_PATH) and os.path.exists(META_PATH)):
        st.info("아직 저장된 파일이 없습니다. 위에서 '💾 인덱스+메타 저장'을 먼저 누르세요.")
        return
    idx = faiss.read_index(INDEX_PATH)
    with open(META_PATH, encoding="utf-8") as f:
        meta = json.load(f)
    recs = meta.get("records", [])

    c1, c2 = st.columns(2)
    c1.write(f"📦 **{INDEX_PATH}** · {os.path.getsize(INDEX_PATH) // 1024} KB\n\n"
             f"임베딩 벡터 {idx.ntotal}개 · {idx.d}차원 (정규화 float32)")
    c2.write(f"📝 **{META_PATH}** · {os.path.getsize(META_PATH) // 1024} KB\n\n"
             f"모델 `{meta.get('model_name')}` · 청크 {len(recs)}개")

    # ① index.faiss 에 저장된 '실제 임베딩 벡터'를 복원해서 보여준다
    n = min(5, idx.ntotal)
    vecs = idx.reconstruct_n(0, n)                      # (n, d) float32
    labels = [f'{recs[i]["source"]}#{recs[i]["chunk_id"]}' for i in range(n)]
    st.caption(f"① index.faiss 에 저장된 임베딩 벡터 — 상위 {n}개 청크 × 앞 12차원 "
               f"(정규화되어 ‖v‖≈1 → 내적=코사인)")
    sample = pd.DataFrame(np.round(vecs[:, :12], 4), index=labels,
                          columns=[f"d{j}" for j in range(12)])
    sample.insert(0, "‖v‖", np.round(np.linalg.norm(vecs, axis=1), 3))
    st.dataframe(sample, width='stretch')

    # ② index_meta.json 에 저장된 청크 메타 (벡터와 1:1 대응)
    st.caption("② index_meta.json 에 저장된 청크 메타 (위 벡터와 같은 순서로 1:1 대응)")
    st.dataframe(pd.DataFrame(
        [{"source": r["source"], "chunk_id": r["chunk_id"],
          "글자수": len(r["text"]), "미리보기": r["text"][:60]} for r in recs]),
        width='stretch', height=280)


def _show_loaded(kb):
    """불러온 인덱스/메타 정보를 화면에 표시한다."""
    st.success("로드 완료 — 저장돼 있던 인덱스와 청크 메타를 복원했습니다.")
    m1, m2, m3 = st.columns(3)
    m1.metric("벡터 수", kb["index"].ntotal)
    m2.metric("차원", kb["index"].d)
    m3.metric("복원된 청크", len(kb["records"]))
    st.write(f"임베딩 모델: `{kb['model_name']}`")
    st.caption("복원된 청크 미리보기 (상위 10개)")
    st.dataframe(pd.DataFrame(
        [{"source": r["source"], "chunk_id": r["chunk_id"], "미리보기": r["text"][:60]}
         for r in kb["records"][:10]]), width='stretch')


def save_kb(kb):
    faiss.write_index(kb["index"], INDEX_PATH)
    with open(META_PATH, "w", encoding="utf-8") as f:
        json.dump({"model_name": kb["model_name"], "records": kb["records"]},
                  f, ensure_ascii=False)


def load_into(kb):
    kb["index"] = faiss.read_index(INDEX_PATH)
    with open(META_PATH, encoding="utf-8") as f:
        meta = json.load(f)
    kb["records"], kb["model_name"] = meta["records"], meta["model_name"]


def render(kb):
    st.subheader("Stage 4 · 저장  ✅모범답안(persist + 메타 JSON)")
    if not kb:
        return
    c0a, c0b = st.columns(2)
    c0a.metric("현재 벡터 수", kb["index"].ntotal)
    c0b.metric("현재 차원", kb["index"].d)
    saved = os.path.exists(INDEX_PATH) and os.path.exists(META_PATH)
    st.caption(f"저장 파일: {INDEX_PATH}, {META_PATH} — {'있음 ✅' if saved else '없음(먼저 저장하세요)'}")

    c1, c2 = st.columns(2)
    if c1.button("💾 인덱스+메타 저장"):
        save_kb(kb)
        st.success(f"{INDEX_PATH}, {META_PATH} 저장 완료")
    if c2.button("📂 불러오기"):
        if not saved:
            st.warning("저장된 파일이 없습니다. 먼저 '💾 인덱스+메타 저장'을 누르세요.")
        else:
            try:
                load_into(kb)
                _show_loaded(kb)          # 불러온 정보를 화면에 바로 표시
            except Exception as e:  # noqa: BLE001
                st.error(f"로드 실패: {e}")

    st.divider()
    st.markdown("#### 💾 저장된 임베딩 데이터 보기 (디스크에 어떻게 저장됐나)")
    _show_saved()
