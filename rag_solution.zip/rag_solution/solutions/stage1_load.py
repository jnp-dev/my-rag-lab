"""Stage 1 모범답안 — 적재/파싱 확장 과제 4종 적용.

  1) 여러 인코딩 자동 감지 (UTF-8 / CP949 / EUC-KR)
  2) 머리말·꼬리말·페이지번호 같은 잡음 제거
  3) .docx 지원 (python-docx)
  4) 추출 텍스트에 페이지 번호 메타데이터 부착 ([p.N] 마커 + pages 리스트)
"""
import io
import re
from collections import Counter
from glob import glob
from pathlib import Path

import streamlit as st
from pypdf import PdfReader

try:
    import docx  # python-docx
    _HAS_DOCX = True
except ImportError:
    _HAS_DOCX = False


# ── 1) 인코딩 자동 감지 ────────────────────────────────────────────
def _decode(data: bytes) -> str:
    """한국어 문서에서 흔한 인코딩들을 순서대로 시도한다."""
    for enc in ("utf-8", "cp949", "euc-kr"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "ignore")  # 마지막 안전망


# ── 2) 잡음 제거 (머리말·꼬리말·페이지번호) ──────────────────────────
def _is_page_number(line: str) -> bool:
    """페이지 번호처럼 보이는 줄인가? 예) '12', '- 3 -', 'Page 4', '3/10'."""
    s = line.strip()
    return bool(re.fullmatch(r"[-–—]*\s*(page|p\.?)?\s*\d+\s*[-–—/]*\s*\d*", s, re.I))


def _clean_pages(pages: list[str]) -> list[str]:
    """페이지번호 줄을 먼저 지운 뒤, 페이지마다 반복되는 첫/끝 줄(머리말·꼬리말)을 제거한다.
    여러 페이지의 절반 이상에서 똑같이 등장하는 첫/끝 줄을 머리말/꼬리말로 간주."""
    # 1차: 페이지번호 줄 제거 (머리말/꼬리말 탐지가 진짜 첫/끝 줄을 보도록)
    stripped = [[l for l in p.splitlines() if not _is_page_number(l)] for p in pages]
    # 2차: 반복되는 첫/끝 줄 탐지
    firsts, lasts = Counter(), Counter()
    for lines in stripped:
        nonempty = [l for l in lines if l.strip()]
        if nonempty:
            firsts[nonempty[0].strip()] += 1
            lasts[nonempty[-1].strip()] += 1
    n = max(1, len(pages))
    repeated = len(pages) >= 3                       # 3쪽 이상일 때만 머리말 추정
    header = {k for k, c in firsts.items() if repeated and c >= n * 0.5}
    footer = {k for k, c in lasts.items() if repeated and c >= n * 0.5}
    cleaned = []
    for lines in stripped:
        kept = [l for l in lines
                if l.strip() not in header and l.strip() not in footer]
        cleaned.append("\n".join(kept).strip())
    return cleaned


# ── PDF: 페이지별 추출 → 정제 ──────────────────────────────────────
def read_pdf_pages(data: bytes) -> list[str]:
    reader = PdfReader(io.BytesIO(data))
    raw = [(p.extract_text() or "") for p in reader.pages]
    return _clean_pages(raw)


def read_pdf(data: bytes) -> str:
    """정제된 페이지들을 줄바꿈으로 합친 전체 텍스트(기본 인터페이스 호환)."""
    return "\n".join(read_pdf_pages(data))


# ── 3) .docx 지원 ─────────────────────────────────────────────────
def read_docx(data: bytes) -> str:
    if not _HAS_DOCX:
        return "_(python-docx 미설치 — `pipenv install python-docx`)_"
    document = docx.Document(io.BytesIO(data))
    return "\n".join(p.text for p in document.paragraphs if p.text.strip())


# ── 적재: 파일/폴더 → docs (+ 4) 페이지 메타데이터) ─────────────────
def _load_one(name: str, data: bytes) -> dict:
    ext = Path(name).suffix.lower()
    source = Path(name).stem
    if ext == ".pdf":
        pages = [pg for pg in read_pdf_pages(data) if pg.strip()]
        # 4) 본문에 [p.N] 마커를 심어 청킹 후에도 페이지 출처를 추적할 수 있게 함
        text = "\n\n".join(f"[p.{i + 1}]\n{pg}" for i, pg in enumerate(pages))
        return {"source": source, "text": text, "n_pages": len(pages),
                "pages": [{"page": i + 1, "text": pg} for i, pg in enumerate(pages)]}
    if ext == ".docx":
        return {"source": source, "text": read_docx(data), "n_pages": 1}
    return {"source": source, "text": _decode(data), "n_pages": 1}   # txt/md 등


def load_documents(files, include_folder):
    docs = []
    for f in files or []:
        docs.append(_load_one(f.name, f.getvalue()))
    if include_folder:
        for path in sorted(glob("docs/*")):
            docs.append(_load_one(path, Path(path).read_bytes()))
    return docs


def render(kb):
    """[탭] 문서별 글자수·페이지수 + 원문 미리보기 (페이지 마커 포함)."""
    st.subheader("Stage 1 · 적재/파싱  ✅모범답안(인코딩·정제·docx·페이지메타)")
    if not kb:
        st.info("← 사이드바에서 문서를 넣고 **파이프라인 실행**을 누르세요.")
        return
    for d in kb["docs"]:
        with st.expander(f"📄 {d['source']} · {len(d['text']):,}자 · {d.get('n_pages', 1)}p"):
            st.text(d["text"][:1500] + ("..." if len(d["text"]) > 1500 else ""))
