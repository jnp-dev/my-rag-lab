"""Stage 3 모범답안 — 임베딩 확장 과제:
  1) 청크 코사인 유사도 히트맵 (Altair — matplotlib 불필요)
  2) 가장 비슷한 청크 쌍 Top-N (검색이 무엇을 가까이 보는지)
  3) PCA 2D 산점도(출처별 색)
"""
import altair as alt
import numpy as np
import pandas as pd
import streamlit as st

from stages.stage3_embed import get_model, embed, pca_2d  # noqa: F401 (app_solution이 사용)


def _heatmap(sim, labels):
    """코사인 유사도 행렬을 Altair rect 히트맵으로."""
    df = pd.DataFrame(sim, index=labels, columns=labels)
    df.index.name = "A"
    long = df.reset_index().melt(id_vars="A", var_name="B", value_name="유사도")
    return (alt.Chart(long).mark_rect().encode(
        x=alt.X("B:N", sort=labels, title=None),
        y=alt.Y("A:N", sort=labels, title=None),
        color=alt.Color("유사도:Q", scale=alt.Scale(scheme="blues")),
        tooltip=["A", "B", alt.Tooltip("유사도:Q", format=".2f")],
    ).properties(height=400))


def render(kb):
    st.subheader("Stage 3 · 임베딩  ✅모범답안(히트맵·유사쌍)")
    if not kb:
        return
    emb, recs = kb["emb"], kb["records"]
    st.write(f"임베딩 shape **{emb.shape}** · 정규화되어 내적=코사인")
    coords = pca_2d(emb)
    st.scatter_chart(pd.DataFrame({"x": coords[:, 0], "y": coords[:, 1],
                                   "source": [r["source"] for r in recs]}),
                     x="x", y="y", color="source")
    n = min(15, len(emb))
    sim = np.round(emb[:n] @ emb[:n].T, 2)
    labels = [f'{r["source"]}#{r["chunk_id"]}' for r in recs[:n]]
    st.write(f"코사인 유사도 히트맵 (상위 {n}개):")
    st.altair_chart(_heatmap(sim, labels), width='stretch')
    # 2) 가장 비슷한 청크 쌍 Top 10
    full = emb @ emb.T
    np.fill_diagonal(full, -1.0)
    pairs = []
    for i in range(len(emb)):
        j = int(full[i].argmax())
        if i < j:
            pairs.append((round(float(full[i, j]), 3),
                          f'{recs[i]["source"]}#{recs[i]["chunk_id"]}',
                          f'{recs[j]["source"]}#{recs[j]["chunk_id"]}'))
    pairs.sort(reverse=True)
    st.write("가장 비슷한 청크 쌍 Top 10:")
    st.dataframe(pd.DataFrame(pairs[:10], columns=["유사도", "청크A", "청크B"]),
                 width='stretch')
