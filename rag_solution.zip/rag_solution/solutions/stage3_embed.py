"""Stage 3 모범답안 — 임베딩 확장 과제:
  1) PCA 3D 산점도(출처별 색) — 회전 · 확대해 보고, 고른 청크와 이웃을 강조
  2) 2D 산점도에서 점을 클릭(또는 목록에서 선택) → 그 청크 전문 + 가장 가까운 이웃
  3) 청크 코사인 유사도 히트맵 (Altair — matplotlib 불필요)
  4) 가장 비슷한 청크 쌍 Top-N — 행을 고르면 두 청크 전문을 나란히
"""
import html

import altair as alt
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from stages.stage3_embed import get_model, embed, pca_2d  # noqa: F401 (app_solution이 사용)

SEL_KEY = "s3_chunk"      # 지금 고른 청크 번호(records 순서)
N_NEIGHBORS = 5
TOP_PAIRS = 10


def _label(r):
    return f'{r["source"]}#{r["chunk_id"]}'


def _preview(text, n=60):
    t = " ".join(str(text).split())
    return t if len(t) <= n else t[:n] + "…"


def _pca(emb, k=3):
    """sklearn 없이 SVD로 k차원 투영. 좌표와 각 축이 설명하는 분산 비율을 돌려준다."""
    X = emb - emb.mean(axis=0, keepdims=True)
    U, S, _ = np.linalg.svd(X, full_matrices=False)
    coords = U[:, :k] * S[:k]
    var = (S ** 2) / max(float((S ** 2).sum()), 1e-12)
    if coords.shape[1] < k:  # 청크가 k개보다 적을 때
        coords = np.pad(coords, ((0, 0), (0, k - coords.shape[1])))
        var = np.pad(var, (0, k - len(var)))
    return coords, var[:k]


def _heatmap(sim, labels):
    """코사인 유사도 행렬을 Altair rect 히트맵으로."""
    df = pd.DataFrame(sim, index=labels, columns=labels)
    df.index.name = "A"
    long = df.reset_index().melt(id_vars="A", var_name="B", value_name="유사도")
    return (alt.Chart(long).mark_rect().encode(
        x=alt.X("B:N", sort=labels, title=None),
        y=alt.Y("A:N", sort=labels, title=None),
        color=alt.Color("유사도:Q", scale=alt.Scale(scheme="blues")),
        tooltip=["A", "B", alt.Tooltip("유사도:Q", format=".2f")],
    ).properties(height=400))


def _chunk_box(rec, title, extra=""):
    """청크 하나의 전문을 테두리 상자에."""
    with st.container(border=True):
        st.markdown(f"**{title}** · `{_label(rec)}` · {len(rec['text'])}자 {extra}")
        st.code(rec["text"], language=None, wrap_lines=True, height=280)


def _on_pick():
    """2D 산점도에서 점을 클릭하면 그 청크를 '지금 고른 청크'로."""
    ev = st.session_state.get("s3_2d")
    pts = (ev or {}).get("selection", {}).get("pick") or []
    if pts and "idx" in pts[0]:
        st.session_state[SEL_KEY] = int(pts[0]["idx"])


def _scatter_2d(df, sel):
    pick = alt.selection_point(name="pick", fields=["idx"], on="click")
    base = alt.Chart(df).mark_circle(size=70).encode(
        x=alt.X("PC1:Q"), y=alt.Y("PC2:Q"),
        color=alt.Color("source:N", title="출처"),
        tooltip=["청크", "미리보기"],
    ).add_params(pick)
    mark = alt.Chart(df[df["idx"] == sel]).mark_point(
        shape="diamond", size=320, color="red", strokeWidth=2.5, filled=False,
    ).encode(x="PC1:Q", y="PC2:Q")
    return (base + mark).properties(height=380)


def _scatter_3d(df, sel, neighbors):
    fig = go.Figure()
    for src, g in df.groupby("source", sort=False):
        fig.add_trace(go.Scatter3d(
            x=g["PC1"], y=g["PC2"], z=g["PC3"], mode="markers", name=str(src),
            marker=dict(size=4, opacity=0.75),
            text=g["hover"], hovertemplate="%{text}<extra></extra>",
        ))
    s = df.iloc[sel]
    for j in neighbors:  # 고른 청크 → 이웃을 선으로
        n = df.iloc[j]
        fig.add_trace(go.Scatter3d(
            x=[s["PC1"], n["PC1"]], y=[s["PC2"], n["PC2"]], z=[s["PC3"], n["PC3"]],
            mode="lines", line=dict(color="orange", width=3),
            hoverinfo="skip", showlegend=False,
        ))
    fig.add_trace(go.Scatter3d(
        x=df.iloc[neighbors]["PC1"], y=df.iloc[neighbors]["PC2"], z=df.iloc[neighbors]["PC3"],
        mode="markers", name=f"이웃 {len(neighbors)}개",
        marker=dict(size=7, color="orange", line=dict(color="black", width=1)),
        text=df.iloc[neighbors]["hover"], hovertemplate="%{text}<extra></extra>",
    ))
    fig.add_trace(go.Scatter3d(
        x=[s["PC1"]], y=[s["PC2"]], z=[s["PC3"]], mode="markers", name="고른 청크",
        marker=dict(size=10, color="red", symbol="diamond", line=dict(color="black", width=1)),
        text=[s["hover"]], hovertemplate="%{text}<extra></extra>",
    ))
    fig.update_layout(
        height=560, margin=dict(l=0, r=0, t=10, b=0),
        scene=dict(xaxis_title="PC1", yaxis_title="PC2", zaxis_title="PC3"),
        legend=dict(orientation="h", y=1.02),
    )
    return fig


def render(kb):
    st.subheader("Stage 3 · 임베딩  ✅모범답안(3D · 전문 보기 · 유사쌍)")
    if not kb:
        return
    emb, recs = kb["emb"], kb["records"]
    N = len(emb)
    labels = [_label(r) for r in recs]
    full = emb @ emb.T  # 정규화 벡터라 내적 = 코사인 유사도

    coords, var = _pca(emb, 3)
    st.write(f"임베딩 shape **{emb.shape}** (청크 수 × 차원) · 정규화되어 내적=코사인")
    st.write(f"→ PCA 3D 투영 shape **{coords.shape}** · PC1~PC3이 전체 분산의 "
             f"**{var.sum() * 100:.1f}%** 설명 (PC1 {var[0]*100:.1f}% · PC2 {var[1]*100:.1f}% · PC3 {var[2]*100:.1f}%)")
    st.caption(f"{emb.shape[1]}차원을 3차원으로 눌러 담은 그림입니다. 가까워 보여도 실제 유사도는 아래 표의 값으로 확인합니다.")

    df = pd.DataFrame({
        "idx": range(N), "PC1": coords[:, 0], "PC2": coords[:, 1], "PC3": coords[:, 2],
        "source": [r["source"] for r in recs], "청크": labels,
        "미리보기": [_preview(r["text"]) for r in recs],
    })
    df["hover"] = [f"<b>{html.escape(l)}</b><br>{html.escape(_preview(r['text'], 80))}"
                   for l, r in zip(labels, recs)]

    # ── 청크 선택: 목록 또는 2D 산점도 클릭 ──
    if st.session_state.get(SEL_KEY, 0) >= N:
        st.session_state[SEL_KEY] = 0
    st.markdown("#### 청크 고르기")
    st.selectbox("청크", list(range(N)), key=SEL_KEY,
                 format_func=lambda i: f"{labels[i]} · {_preview(recs[i]['text'], 40)}",
                 help="아래 2D 산점도에서 점을 클릭해도 바뀝니다.")
    sel = int(st.session_state[SEL_KEY])

    sims = full[sel].copy()
    sims[sel] = -np.inf
    neighbors = [int(j) for j in np.argsort(-sims)[:min(N_NEIGHBORS, N - 1)]]

    t2d, t3d = st.tabs(["2D (점 클릭으로 선택)", "3D (드래그로 회전)"])
    with t2d:
        st.altair_chart(_scatter_2d(df, sel), key="s3_2d", on_select=_on_pick, width="stretch")
        st.caption("점을 클릭하면 그 청크를 고릅니다. 빨간 마름모가 지금 고른 청크입니다.")
    with t3d:
        st.plotly_chart(_scatter_3d(df, sel, neighbors), key="s3_3d", width="stretch")
        st.caption("빨간 마름모 = 고른 청크 · 주황 = 코사인 유사도가 가장 높은 이웃. "
                   "3D에서는 점 클릭 선택이 안 되므로 위 목록이나 2D 탭에서 고릅니다.")

    left, right = st.columns([3, 2])
    with left:
        _chunk_box(recs[sel], "고른 청크 전문")
    with right:
        st.markdown(f"**가장 가까운 이웃 {len(neighbors)}개**")
        st.dataframe(pd.DataFrame({
            "유사도": [round(float(full[sel, j]), 3) for j in neighbors],
            "청크": [labels[j] for j in neighbors],
            "미리보기": [_preview(recs[j]["text"], 40) for j in neighbors],
        }), hide_index=True, width="stretch")

    # ── 히트맵 ──
    n = min(15, N)
    sim = np.round(full[:n, :n], 2)
    st.markdown(f"#### 코사인 유사도 히트맵 (앞 {n}개)")
    st.altair_chart(_heatmap(sim, labels[:n]), width="stretch")

    # ── 가장 비슷한 청크 쌍 Top-N (서로 다른 쌍 전체에서) ──
    st.markdown(f"#### 가장 비슷한 청크 쌍 Top {TOP_PAIRS}")
    if N < 2:
        st.info("청크가 2개 이상이어야 쌍을 만들 수 있습니다.")
        return
    iu, ju = np.triu_indices(N, k=1)
    order = np.argsort(-full[iu, ju])[:TOP_PAIRS]
    pairs = pd.DataFrame({
        "순위": range(1, len(order) + 1),
        "유사도": [round(float(full[iu[k], ju[k]]), 3) for k in order],
        "청크A": [labels[iu[k]] for k in order],
        "청크B": [labels[ju[k]] for k in order],
        "A 미리보기": [_preview(recs[iu[k]]["text"], 30) for k in order],
        "B 미리보기": [_preview(recs[ju[k]]["text"], 30) for k in order],
    })
    ev = st.dataframe(pairs, hide_index=True, width="stretch", key="s3_pairs",
                      on_select="rerun", selection_mode="single-row")
    rows = ev.selection.rows
    r = rows[0] if rows else 0
    a, b = int(iu[order[r]]), int(ju[order[r]])
    st.caption(f"표에서 행을 고르면 두 청크 전문을 나란히 보여 줍니다. 지금: {r + 1}위 쌍"
               + ("" if rows else " (기본값)"))
    ca, cb = st.columns(2)
    with ca:
        _chunk_box(recs[a], "청크A", f"· 유사도 {full[a, b]:.3f}")
    with cb:
        _chunk_box(recs[b], "청크B", f"· 유사도 {full[a, b]:.3f}")
