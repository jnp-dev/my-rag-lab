"""Stage 8 모범답안 — 평가/검수 확장 과제:
  1) 기대답 키워드 포함 여부 보조 채점(kw_hit)
  2) 오답·출처실패 케이스만 필터링
  3) 평가 리포트(지표 + 실패 사례) Markdown 내보내기
  4) Gemini/Ollama 제공자 토글 — 선택한 LLM 으로 전체 채점 (Stage 6 공용)
"""
import pandas as pd
import streamlit as st

from stages.stage5_search import retrieve
from stages.stage8_eval import (  # noqa: F401
    EVAL_COLS, _is_trap, eval_metrics, eval_metrics_by_category,
    SAMPLE_SETS, load_sample,
)
from solutions.stage6_generate import build_prompt, generate, llm_controls


def _kw_hit(expected, answer):
    """기대답의 주요 토큰(2글자+)이 실제 답에 절반 이상 포함됐는가."""
    kws = [w for w in str(expected).replace(",", " ").split() if len(w) >= 2]
    if not kws:
        return None
    return sum(w in str(answer) for w in kws) / len(kws) >= 0.5


def run_eval(test_df, k, provider="auto", model_name=None, temperature=0.2):
    """각 질문을 검색→생성(선택한 LLM)→자동 채점한다."""
    rows = []
    for _, r in test_df.iterrows():
        q = str(r.get("question", "")).strip()
        if not q:
            continue
        hits = retrieve(q, k)
        srcs = sorted({h["source"] for h in hits})
        prompt, ctx = build_prompt(q, hits)
        ans = generate(prompt, ctx, provider, model_name, temperature)
        refused = "찾을 수 없습니다" in ans
        exp_src = str(r.get("expected_source", "")).strip()
        trap = _is_trap(r.get("trap", 0))
        rows.append({
            "id": r.get("id", ""),
            "category": str(r.get("category", "") or "").strip() or "전체",
            "question": q,
            "expected_answer": r.get("expected_answer", ""), "expected_source": exp_src,
            "trap": trap, "actual_answer": ans, "retrieved_sources": ", ".join(srcs),
            "top_score": round(hits[0]["score"], 3) if hits else None,
            "source_hit": (exp_src in srcs) if exp_src else None, "refused": refused,
            "kw_hit": _kw_hit(r.get("expected_answer", ""), ans),     # 1) 키워드 보조
            "verdict": ("정답" if (trap and refused) else
                        ("오답" if (trap and not refused) else "미검수")),
        })
    return pd.DataFrame(rows)


def _is_fail(df):
    return (df["verdict"] == "오답") | ((df["source_hit"] == False) & (~df["trap"]))  # noqa: E712


def _report_md(df, metrics, provider, model_name):
    acc, src_rate, halluc, top = metrics
    pct = lambda v: "-" if v is None else f"{v*100:.0f}%"
    lines = ["# RAG 평가 리포트", "",
             f"- 생성기: {provider} / {model_name}",
             f"- 검수 정답률: {pct(acc)}", f"- 출처 적중률: {pct(src_rate)}",
             f"- 환각률: {pct(halluc)}",
             f"- 평균 top 유사도: {'-' if top is None else f'{top:.2f}'}", ""]
    by_cat = eval_metrics_by_category(df)
    if by_cat is not None:
        lines += ["## 구분별 지표", "",
                  "| " + " | ".join(by_cat.columns) + " |",
                  "|" + "---|" * len(by_cat.columns)]
        lines += ["| " + " | ".join(str(v) for v in row) + " |"
                  for row in by_cat.itertuples(index=False)]
        lines.append("")
    lines.append("## 실패 사례")
    for _, r in df[_is_fail(df)].iterrows():
        lines.append(f"- **{r['question']}** → {str(r['actual_answer'])[:80]} "
                     f"(출처적중={r['source_hit']}, kw={r['kw_hit']})")
    return "\n".join(lines)


def render(kb, k):
    st.subheader("Stage 8 · 평가/검수  ✅모범답안(키워드보조·실패필터·구분별지표·리포트)")
    if not kb:
        st.info("먼저 파이프라인을 실행하세요.")
        return

    provider, model_name, temp = llm_controls("eval_")     # 4) 채점에 쓸 LLM 선택
    st.caption("선택한 LLM 으로 모든 질문을 채점합니다. 로컬 모델은 문항 수만큼 시간이 걸릴 수 있어요.")

    sample = st.selectbox("샘플 테스트표", list(SAMPLE_SETS), key="sol_eval_sample")
    if st.button("📋 샘플 테스트표 불러오기"):
        try:
            st.session_state.sol_test_df = load_sample(sample)
        except Exception:  # noqa: BLE001
            st.session_state.sol_test_df = pd.DataFrame(columns=EVAL_COLS)
    st.session_state.setdefault("sol_test_df", pd.DataFrame(
        [{"id": 1, "question": "", "expected_answer": "", "expected_source": "",
          "trap": 0, "category": ""}]))
    test_df = st.data_editor(st.session_state.sol_test_df, num_rows="dynamic",
                             width='stretch', height=220, key="sol_eval_editor")

    if st.button("▶ 전체 실행 & 채점"):
        with st.spinner(f"{provider}({model_name}) 로 채점 중..."):
            st.session_state.sol_eval_res = run_eval(test_df, k, provider, model_name, temp)
            st.session_state.sol_eval_meta = (provider, model_name)

    if "sol_eval_res" in st.session_state:
        res = st.session_state.sol_eval_res
        if res.empty:
            st.warning("채점할 질문이 없습니다 — 테스트표에 질문을 입력하세요.")
            return
        prov, mdl = st.session_state.get("sol_eval_meta", (provider, model_name))
        only_fail = st.checkbox("오답·출처실패만 보기", key="sol_fail")    # 2) 필터
        view = res[_is_fail(res)] if only_fail else res
        st.dataframe(view, width='stretch', height=300)
        metrics = eval_metrics(res)
        acc, src_rate, halluc, top = metrics
        m = st.columns(4)
        m[0].metric("정답률", f"{acc*100:.0f}%" if acc is not None else "-")
        m[1].metric("출처적중", f"{src_rate*100:.0f}%" if src_rate is not None else "-")
        m[2].metric("환각률", f"{halluc*100:.0f}%" if halluc is not None else "-")
        m[3].metric("평균 top", f"{top:.2f}" if top is not None else "-")
        by_cat = eval_metrics_by_category(res)
        if by_cat is not None:
            st.markdown("**구분별 지표** — 성격이 다른 질문은 나눠 봐야 차이가 보입니다")
            st.dataframe(by_cat, width='stretch', hide_index=True)
        st.caption(f"채점 생성기: {prov} · `{mdl}`")
        st.download_button("⬇ 평가 리포트(.md)",
                           _report_md(res, metrics, prov, mdl).encode("utf-8"),
                           "eval_report.md")                            # 3) 리포트
