"""Stage 2 모범답안 — 청킹 확장 과제:
  1) 마크다운 헤더(#, ##) 기준 분할
  2) 문단(\n\n)·문장 단위로 자연스러운 경계 분할
  3) 너무 짧은 청크는 앞 조각과 병합
  4) 청크 길이 분포 히스토그램 개선(구간별 개수)
"""
import re

import numpy as np
import pandas as pd
import streamlit as st

MIN_CHARS = 100  # 이보다 짧은 청크는 앞 조각과 병합


def _split_sentences(text: str):
    """마침표/물음표/느낌표(한·영) 뒤 공백을 문장 경계로 본다."""
    return [p for p in re.split(r"(?<=[.!?。])\s+", text.strip()) if p.strip()]


def _by_size(text: str, size: int, overlap: int):
    out, i = [], 0
    while i < len(text):
        out.append(text[i:i + size])
        i += max(1, size - overlap)
    return out


def chunk_text(text: str, size: int, overlap: int):
    """헤더 → 문단 → (길면)문장/size 순으로 자르고, 짧은 청크는 앞과 병합."""
    text = text.strip()
    # 1) 마크다운 헤더 줄을 섹션 경계로 분리
    if re.search(r"(?m)^#{1,6}\s", text):
        sections = re.split(r"(?m)^(?=#{1,6}\s)", text)
    else:
        sections = [text]

    raw = []
    for sec in sections:
        sec = sec.strip()
        if not sec:
            continue
        # 2) 문단 단위, 너무 길면 문장→size 로 추가 분할
        for para in (p for p in sec.split("\n\n") if p.strip()):
            if len(para) <= size:
                raw.append(para)
                continue
            buf = ""
            for sent in _split_sentences(para):
                if len(buf) + len(sent) + 1 <= size:
                    buf = (buf + " " + sent).strip()
                else:
                    if buf:
                        raw.append(buf)
                    if len(sent) > size:
                        raw.extend(_by_size(sent, size, overlap))
                        buf = ""
                    else:
                        buf = sent
            if buf:
                raw.append(buf)

    # 3) 너무 짧은 청크는 앞 조각과 병합
    merged = []
    for c in raw:
        if merged and len(c) < MIN_CHARS:
            merged[-1] = (merged[-1] + "\n" + c).strip()
        else:
            merged.append(c)
    return merged


def make_chunks(docs, size, overlap):
    records = []
    for d in docs:
        for j, c in enumerate(chunk_text(d["text"], size, overlap)):
            if c.strip():
                records.append({"source": d["source"], "chunk_id": j, "text": c})
    return records


def render(kb):
    st.subheader("Stage 2 · 청킹  ✅모범답안(헤더/문장 분할·병합·히스토그램)")
    if not kb:
        return
    lens = np.array([len(r["text"]) for r in kb["records"]])
    st.write(f"총 청크 **{len(lens)}개** · 평균 {lens.mean():.0f} · 중앙 {np.median(lens):.0f} · 최대 {lens.max()}자")
    # 4) 길이 분포 히스토그램(구간별 개수)
    counts, edges = np.histogram(lens, bins=10)
    hist = pd.DataFrame({"구간": [f"{int(edges[i])}~{int(edges[i+1])}" for i in range(len(counts))],
                         "개수": counts}).set_index("구간")
    st.bar_chart(hist)
    df = pd.DataFrame([{"source": r["source"], "chunk_id": r["chunk_id"],
                        "길이": len(r["text"]), "미리보기": r["text"][:60]} for r in kb["records"]])
    st.dataframe(df, width='stretch', height=280)
