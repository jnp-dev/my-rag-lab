"""Stage 6 모범답안 — 생성 확장 과제:
  1) 근거 청크 인용 표시([문서#조각])
  2) 답변 말투/길이 토글(간결/상세)
  3) 모델명·온도(temperature) UI 노출
  4) 로컬 Ollama 모델 지원
  5) Claude(Anthropic) 제공자 지원

generate/_get_api_key/_gen_ollama/_ollama_models 는 base(stages.stage6_generate)의
단일 구현을 그대로 import 한다 → 3벌(base/lab/solution) 로직 일치 보장.
"""
import streamlit as st

from stages.stage6_generate import (              # noqa: F401  (재노출/재사용)
    retrieve, generate, _ollama_models, _get_api_key, _get_claude_key,
    _HAS_ANTHROPIC, active_provider, GEN_MODEL, CLAUDE_MODEL, OLLAMA_MODEL,
)


def build_prompt(query, hits, style="간결"):
    context = "\n\n".join(f"[{h['source']}#{h['chunk_id']}] {h['text']}" for h in hits)
    tone = "간결하게 핵심만" if style == "간결" else "근거를 들어 자세히"
    prompt = (f"아래 [컨텍스트]만 근거로 한국어로 {tone} 답하라. "
              "컨텍스트에 없으면 '문서에서 찾을 수 없습니다'라고만 답하라.\n\n"
              f"[컨텍스트]\n{context}\n\n[질문]\n{query}\n\n[답변]")
    return prompt, context


def llm_controls(prefix=""):
    """Claude/Gemini/Ollama 제공자·모델·온도 위젯 → (provider, model, temperature) 반환.
    provider 는 base generate 와 동일한 소문자 컨벤션 {'auto','claude','gemini','ollama'}.
    Stage 6·7·8 이 공용으로 사용. prefix 로 위젯 key 충돌 방지."""
    c1, c2 = st.columns(2)
    labels = {"자동": "auto", "Claude(클라우드)": "claude",
              "Gemini(클라우드)": "gemini", "Ollama(로컬)": "ollama"}
    label = c1.radio("LLM 제공자", list(labels), horizontal=True, key=f"{prefix}provider")
    provider = labels[label]
    temp = c2.slider("온도", 0.0, 1.0, 0.2, 0.1, key=f"{prefix}temp",
                     help="Claude 는 SDK 1.x 에서 온도 미지원 — Gemini/Ollama 에만 적용됩니다.")
    if provider == "ollama":
        models = _ollama_models()
        if models:
            model = st.selectbox("Ollama 모델", models, key=f"{prefix}model_o")
        else:
            model = st.text_input("Ollama 모델", OLLAMA_MODEL, key=f"{prefix}model_ot")
            st.caption("⚠️ Ollama 미연결 — `ollama serve` 후 `ollama pull` 필요")
    elif provider == "gemini":
        model = st.text_input("Gemini 모델", GEN_MODEL, key=f"{prefix}model_g")
    elif provider == "claude":
        model = st.text_input("Claude 모델", CLAUDE_MODEL, key=f"{prefix}model_c")
        if not (_HAS_ANTHROPIC and _get_claude_key()):
            st.caption("⚠️ Claude 사용 불가 — `pipenv install anthropic` + CLAUDE_API_KEY 필요")
    else:
        model = None  # auto
    return provider, model, temp


def render(kb, k):
    st.subheader("Stage 6 · 생성  ✅모범답안(인용·말투·Claude/Gemini/Ollama)")
    if not kb:
        return
    provider, model, temp = llm_controls("g6_")
    style = st.radio("말투/길이", ["간결", "상세"], horizontal=True, key="g6_style")
    gq = st.text_input("질문", key="sol_gen_q")
    if not gq:
        return
    hits = retrieve(gq, k)
    prompt, ctx = build_prompt(gq, hits, style)
    with st.spinner(f"{provider} 생성 중... (로컬 모델은 다소 느릴 수 있음)"):
        ans = generate(prompt, ctx, provider, model, temp)
    st.markdown("**답변**"); st.write(ans)
    used = active_provider() if provider == "auto" else provider
    temp_note = "온도 미지원" if used == "claude" else f"온도 {temp}"
    st.caption(f"생성기: {used} · `{model or '기본'}` · {temp_note}")
    st.markdown("**인용 근거**")
    for h in hits:
        st.markdown(f"- `[{h['source']}#{h['chunk_id']}]` 유사도 {h['score']:.2f}")
    with st.expander("프롬프트 보기"):
        st.text(prompt)
