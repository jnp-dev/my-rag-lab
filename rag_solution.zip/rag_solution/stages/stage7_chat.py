"""Stage 7 · 챗봇: 단발 → 멀티턴 대화.

LLM 제공자/모델 선택은 Stage 6·8 과 동일한 위젯(llm_controls)을 쓴다:
Ollama 선택 시 설치된 모델을 드롭다운으로 보여주고(미연결이면 입력+안내),
선택값을 generate(prompt, ctx, provider, model) 로 그대로 넘긴다.
"""
import streamlit as st

from stages.stage5_search import retrieve
from stages.stage6_generate import build_prompt, generate, llm_controls


def render(kb, k):
    st.subheader("Stage 7 · 챗봇")
    if not kb:
        return
    provider, model = llm_controls("chat_")
    st.session_state.setdefault("msgs", [])
    for m in st.session_state.msgs:
        st.chat_message(m["role"]).write(m["content"])
    if q := st.chat_input("문서 내용을 질문하세요"):
        st.chat_message("user").write(q)
        hits = retrieve(q, k)
        prompt, context = build_prompt(q, hits)
        ans = generate(prompt, context, provider, model or None)
        ans += "\n\n**출처:** " + ", ".join(sorted({h["source"] for h in hits}))
        with st.chat_message("assistant"):
            st.write(ans)
            with st.expander("근거 청크"):
                for h in hits:
                    st.markdown(f"**[{h['source']}#{h['chunk_id']}]** "
                                f"(유사도 {h['score']:.2f})\n\n{h['text']}")
        st.session_state.msgs += [{"role": "user", "content": q},
                                  {"role": "assistant", "content": ans}]