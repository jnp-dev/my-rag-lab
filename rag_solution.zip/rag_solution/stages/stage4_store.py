"""Stage 4 · 저장: 벡터 → FAISS 인덱스."""
import faiss
import streamlit as st


def build_index(emb):
    index = faiss.IndexFlatIP(emb.shape[1])  # 정규화 + 내적 = 코사인
    index.add(emb)
    return index


def render(kb):
    st.subheader("Stage 4 · 저장 (벡터 인덱스)")
    if not kb:
        return
    st.metric("인덱스에 저장된 벡터 수", kb["index"].ntotal)
    st.metric("벡터 차원", kb["index"].d)
    st.write("유사도: 정규화 임베딩 + 내적(IndexFlatIP) = 코사인 유사도")
