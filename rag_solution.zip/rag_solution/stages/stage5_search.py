"""Stage 5 · 검색: 질문 → top-k 조각."""
import pandas as pd
import streamlit as st

from stages.stage3_embed import get_model


def retrieve(query, k):
    kb = st.session_state.kb
    model = get_model(kb["model_name"])
    q = model.encode([query], normalize_embeddings=True).astype("float32")
    scores, idx = kb["index"].search(q, k)
    hits = []
    for rank, i in enumerate(idx[0]):
        if i < 0:
            continue
        r = dict(kb["records"][i]); r["score"] = float(scores[0][rank])
        hits.append(r)
    return hits


def render(kb, k):
    st.subheader("Stage 5 · 검색")
    if not kb:
        return
    sq = st.text_input("검색어를 입력하면 가까운 top-k 청크를 보여줍니다", key="search_q")
    if sq:
        hits = retrieve(sq, k)
        st.dataframe(pd.DataFrame([
            {"순위": i + 1, "source": h["source"], "chunk_id": h["chunk_id"],
             "유사도": round(h["score"], 3), "미리보기": h["text"][:80]}
            for i, h in enumerate(hits)]), width='stretch')
