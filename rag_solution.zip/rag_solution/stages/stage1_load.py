"""Stage 1 · 적재/파싱: 파일 → 순수 텍스트."""
import io
from glob import glob
from pathlib import Path

import streamlit as st
from pypdf import PdfReader


def read_pdf(data: bytes) -> str:
    reader = PdfReader(io.BytesIO(data))
    return "\n".join((p.extract_text() or "") for p in reader.pages)


def load_documents(files, include_folder):
    """[{'source':.., 'text':..}] 원문(파싱 결과) 리스트."""
    docs = []
    for f in files or []:
        suffix = Path(f.name).suffix.lower()
        data = f.getvalue()
        text = read_pdf(data) if suffix == ".pdf" else data.decode("utf-8", "ignore")
        docs.append({"source": Path(f.name).stem, "text": text})
    if include_folder:
        for path in sorted(glob("docs/*")):
            docs.append({"source": Path(path).stem,
                         "text": Path(path).read_text(encoding="utf-8", errors="ignore")})
    return docs


def render(kb):
    st.subheader("Stage 1 · 적재 / 파싱")
    if not kb:
        st.info("← 사이드바에서 문서를 넣고 **파이프라인 실행**을 누르세요.")
        return
    for d in kb["docs"]:
        with st.expander(f"📄 {d['source']} · {len(d['text']):,}자"):
            st.text(d["text"][:1500] + ("..." if len(d["text"]) > 1500 else ""))
