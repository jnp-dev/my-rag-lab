"""Stage 3 · 임베딩: 조각 → 의미 벡터."""
import numpy as np
import pandas as pd
import streamlit as st
from sentence_transformers import SentenceTransformer


@st.cache_resource(show_spinner=False)
def get_model(name: str):
    return SentenceTransformer(name)


def embed(records, model):
    return model.encode([r["text"] for r in records],
                        normalize_embeddings=True).astype("float32")


def pca_2d(emb):
    """sklearn 없이 SVD로 2차원 투영."""
    X = emb - emb.mean(axis=0, keepdims=True)
    U, S, _ = np.linalg.svd(X, full_matrices=False)
    return U[:, :2] * S[:2]


def render(kb):
    st.subheader("Stage 3 · 임베딩")
    if not kb:
        return
    emb = kb["emb"]
    st.write(f"임베딩 행렬 shape: **{emb.shape}** (청크 수 × 차원)")
    st.write("첫 청크 벡터 미리보기(앞 10차원):")
    st.code(np.round(emb[0][:10], 4).tolist())
    coords = pca_2d(emb)
    proj = pd.DataFrame({"x": coords[:, 0], "y": coords[:, 1],
                         "source": [r["source"] for r in kb["records"]]})
    st.write("PCA 2D 투영 — 의미가 가까운 청크끼리 모입니다:")
    st.scatter_chart(proj, x="x", y="y", color="source")
