"""Stage 2 · 청킹: 긴 텍스트 → 조각(메타 포함)."""
import pandas as pd
import streamlit as st


def chunk_text(text: str, size: int, overlap: int):
    text = text.strip()
    out, i = [], 0
    while i < len(text):
        out.append(text[i:i + size])
        i += max(1, size - overlap)   # 경계 문맥 보존
    return out


def make_chunks(docs, size, overlap):
    records = []
    for d in docs:
        for j, c in enumerate(chunk_text(d["text"], size, overlap)):
            if c.strip():
                records.append({"source": d["source"], "chunk_id": j, "text": c})
    return records


def render(kb):
    st.subheader("Stage 2 · 청킹")
    if not kb:
        return
    df = pd.DataFrame([{"source": r["source"], "chunk_id": r["chunk_id"],
                        "길이": len(r["text"]), "미리보기": r["text"][:60]}
                       for r in kb["records"]])
    st.write(f"총 청크: **{len(df)}개** · 평균 길이 {df['길이'].mean():.0f}자")
    st.bar_chart(df["길이"])
    st.dataframe(df, width='stretch', height=300)
